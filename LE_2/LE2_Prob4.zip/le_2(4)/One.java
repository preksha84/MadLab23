public class One{
    public One(int x)
    {
        System.out.printf("One %d",x);
}

}
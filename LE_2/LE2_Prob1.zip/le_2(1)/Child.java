class Child extends Mother
{
    int y;
    void display()
    {
        System.out.println("This is a Child class");
    }
}
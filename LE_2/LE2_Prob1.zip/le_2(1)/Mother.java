class Mother
{
    int x;
    void show()
    {
        System.out.println("This is a Mother class");
    }
}
/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    public static void main (String [] args)
    {
  //  Mother m1=new Child(); //error
//    m1.show(); //error
Mother m1=new Mother();
Mother m2=new Mother();
m1.show();
m2.show();
   Child c1=new Child();
   c1.show();
    }
}
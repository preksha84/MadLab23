class Child
{
    void show()
    {
        System.out.println("Hello JUET");
    }
}

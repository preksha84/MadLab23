class Mother
{
    void show()
    {
        System.out.println("Hello World");
    }
    
}